const data ={
    productItems:[
        {
            id : "1" ,
            name : "iphone 13 pro",
            price : 999,
            image : "./pics/iphone13.jpeg"
        },
        {
            id : "2" ,
            name : "samsung",
            price : 899,
            image : "./pics/samsungs21.jpg"
        },
        {
            id : "3" ,
            name : "Oppo Reno 6",
            price : 999,
            image : "./pics/oppo.jpg"
        },
        {
            id : "4" ,
            name : "Realme GT Neo",
            price : 999,
            image : "./pics/real.jpg"
        },
        {
            id : "5" ,
            name : "iphone x",
            price : 1999,
            image : "./pics/iphonex.jpeg"
        },
        {
            id : "6" ,
            name : "oneplus",
            price : 999,
            image : "./pics/oneplus.jpg"
        },
        {
            id : "7" ,
            name : "mi 11 pro",
            price : 2999,
            image : "./pics/mi11.jpg"
        },
        {
            id : "8" ,
            name : "iphone 13 mini",
            price : 999,
            image : "./pics/iphone12.jpeg"
        },
        {
            id : "9" ,
            name : "Vivo x70 Pro",
            price : 3999,
            image : "./pics/vivo.jpg"
        },
        {
            id : "10" ,
            name : "mi 11x",
            price : 3999,
            image : "./pics/mi11x.jpeg"
        },
        {
            id : "11" ,
            name : "iphone 12",
            price : 3999,
            image : "./pics/iphone121.jpeg"
        },
        {
            id : "12" ,
            name : "Google Pixel 6",
            price : 3999,
            image : "./pics/google.png"
        }
    ]
}
export default data;